# <center>Learning Journey</center>

### Description
Learning Journey is an information management app developed by our group for International College students. This application keeps track of grades, course details, class schedules, honors earned, and more during their college years.

Each student can see a list of their grades and rankings during their college years and support a wide variety of filtering functions. Also, you can print or download grades or honors awards, etc. locally.

We have added the function of course schedule and support the switch of semesters to make the users more sticky and to facilitate students' time planning.

I believe you will enjoy this app.
### Software Architecture
The application is programmed in java language, while generating jar packages that can run in any java environment to facilitate application migration.

Our UI interface is built using Java Swing and is broadly divided into four parts: Entity Class, Control Class, GUI Class and Read Class.

### Installation

The application needs to run in java environment, please make sure your java version is in openjdk-17 and above. If you don't have Java environment please go to [https://openjdk.org/](https://openjdk.org/) to download it.

### Instructions

#### Run in the graphical interface

1. Open the directory ./se_project/out/artifacts/Learning_Journey.
2. Double click Learning_Journey.jar to run the program.

#### Run in terminal

1. Enter the following command in the directory where README.md is located.
```bash
cd out/artifacts/Learning_Journey
```
2. Enter the following command.
```bash
java -jar Learning_Journey.jar
```

#### Run in IDEA

1. Open idea.
2. Select Open Project, select the folder se_project.
3. Open MainView.java in src/main/GUI directory.
4. Run the main function.
