function y = compress(x, threshold)
% Compress signal using some function
% transformed signal values below threshold will be removed
%
fx = dwt_haar(x, 4);
% DONE

% Keep only sufficiently large values of fx
y = fx .* (abs(fx)>=threshold);

% Done