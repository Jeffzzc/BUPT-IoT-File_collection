%%  Image preparation 
rgb=imread('mona_lisa.png'); % read the image
figure(1)
imshow(rgb); % display RGB image
[m,n,c]=size(rgb); 
% utilize size() to get height and width
% m represents height, n represents width

% calculate the 8*8 blocks needed to be divided
M = round(m/8);
N = round(n/8);
X = M*N; % the number of blocks

%split the image into 8x8 blocks of pixels
%figure(2)
%count = 1;
%for i=1:M
    %for j=1:N
        %divide blocks
        %block = rgb((i-1)*m/M+1:m/M*i,(j-1)*n/N+1:j*n/N,:);
        %subplot(M,N,count);
        %imshow(block);
        %count=count+1;
    %end
%end

% display the first two blocks
block1=rgb(1:8,1:8,1);
block2=rgb(1:8,9:16,1);
disp(block1); %block1
disp(block2); %block2

%subtract 128 from each pixel values
figure(2)
rgb = im2double(rgb)*255;
for i=1:m
    for j=1:n
        rgb2(i,j)= rgb(i,j)-128; %subtract 128 from each pixel values
    end
end
imshow(rgb2); % display the new image

block3=rgb2(1:8,1:8,1);
block4=rgb2(1:8,9:16,1);
disp(block3); % new block1
disp(block4); % new block2

%% apply dct2 to each block of pixel values
rgb(:,250)= [];
rgb(:,249)= [];
block = mat2cell(rgb,ones(360/8,1)*8,ones(248/8,1)*8); %divide blocks while using mat2cell
%so as to store all results in 8x8 matrices of DCT coefficients values
for i = 1:M
    for j = 1:N
        block{i,j} = block{i,j} - 128;
    end
end

for i = 1:M
    for j = 1:N
        block_dct{i,j} = dct2(block{i,j}); % apply dct2 to each block
    end
end
disp(block_dct{1,1}); %display the first block
disp(block_dct{1,2}); %display the second block

%figure(4)
%imshow(block_dct);

%% Quantisation
% create a standard quantisation matrix Q_std
Q_std = [16,11,10,16,24,40,51,61;
    12,12,14,19,26,58,60,55;
    14,13,16,24,40,57,69,56;
    14,17,22,29,51,87,80,62;
    18,22,37,56,68,109,103,77;
    24,35,55,64,81,104,113,92;
    49,64,78,87,103,121,120,101;
    72,92,95,98,112,100,103,99];
disp(Q_std);

% create Q_high
Q_high = round(2*Q_std);
disp(Q_high);

% create Q_low
Q_low = round(0.4*Q_std);
disp(Q_low);

% Quantisation with Q_std
for i = 1:M
    for j = 1:N
        quan_std{i,j} = round(block_dct{i,j}./Q_std);
    end
end

% Quantisation with Q_high
for i = 1:M
    for j = 1:N
        quan_high{i,j} = round(block_dct{i,j}./Q_high);
    end
end

% Quantisation with Q_low
for i = 1:M
    for j = 1:N
        quan_low{i,j} = round(block_dct{i,j}./Q_low);
    end
end

disp(quan_std{1,1});
disp(quan_std{1,2});
disp(quan_high{1,1});
disp(quan_high{1,2});
disp(quan_low{1,1});
disp(quan_low{1,2});

%% Decompression
% Inverse quantization with Q_std
for i = 1:M
    for j = 1:N
        dequan_std{i,j} = round(quan_std{i,j}.*Q_std);
    end
end

% Inverse quantization with Q_high
for i = 1:M
    for j = 1:N
        dequan_high{i,j} = round(quan_high{i,j}.*Q_high);
    end
end

% Inverse quantization with Q_low
for i = 1:M
    for j = 1:N
        dequan_low{i,j} = round(quan_low{i,j}.*Q_low);
    end
end

disp(dequan_std{1,1});
disp(dequan_std{1,2});
disp(dequan_high{1,1});
disp(dequan_high{1,2});
disp(dequan_low{1,1});
disp(dequan_low{1,2});

% Inverse DCT to 8x8 matrices of DCT coefficients
% for standard one
for i = 1:M
    for j = 1:N
        decom_std{i,j} = round(idct2(dequan_std{i,j})+128);
    end
end

% for high one
for i = 1:M
    for j = 1:N
        decom_high{i,j} = round(idct2(dequan_high{i,j})+128);
    end
end

% for low one
for i = 1:M
    for j = 1:N
        decom_low{i,j} = round(idct2(dequan_low{i,j})+128);
    end
end

disp(decom_std{1,1});
disp(decom_std{1,2});
disp(decom_high{1,1});
disp(decom_high{1,2});
disp(decom_low{1,1});
disp(decom_low{1,2});

%% Image reconstruction
figure(3)
std = cell2mat(decom_std);
imshow(uint8(std));

figure(4)
high = cell2mat(decom_high);
imshow(uint8(high));

figure(5)
low = cell2mat(decom_low);
imshow(uint8(low));

