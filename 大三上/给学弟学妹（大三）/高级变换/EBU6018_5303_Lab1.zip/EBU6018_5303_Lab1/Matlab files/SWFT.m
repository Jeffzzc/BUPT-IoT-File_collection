s = audioread('harp.wav');
sw = fft(s); % do FFT for the signal
figure(1)
plot(s);
figure(2)
plot(abs(sw));