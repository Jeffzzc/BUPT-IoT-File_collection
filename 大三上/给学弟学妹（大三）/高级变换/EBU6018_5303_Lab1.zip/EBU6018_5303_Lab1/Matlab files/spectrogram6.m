%created for part7 g
[s1,fs1] = audioread('Yang voice.m4a'); %girl voice 1
[s2,fs2] = audioread('Wang voice.m4a'); %girl voice 2
[s3,fs3] = audioread('My voice.m4a');   %girl voice 3  my voice
[s4,fs4] = audioread('Wu voice.m4a');   %boy voice 3

%resample the signals to get clearer spectrograms
s1=resample(s1,8000,fs1);
s2=resample(s2,8000,fs2);
s3=resample(s3,8000,fs3);
s4=resample(s4,8000,fs4);

%set parameters
window = hamming(128);
noverlap = 120;
nfft = 2^nextpow2(length(window));

figure(1) %draw the spectrogram for girl voice 1
t1 = 0:1/fs1:2;
y1 = s1';
y1 = y1(1,:);
spectrogram(y1,window,noverlap,nfft,fs1,'yaxis');
h = colorbar;
%figure('Position', [200 250 800 500]);
h.Label.String = 'Power/Frequency(dB/Hz)';
title('Yang voice');

figure(2)  %draw the spectrogram for girl voice 2
t2 = 0:1/fs2:2;
y2 = s2';
y2 = y2(1,:);
spectrogram(y2,window,noverlap,nfft,fs2,'yaxis');
h = colorbar;
%figure('Position', [200 250 800 500]);
h.Label.String = 'Power/Frequency(dB/Hz)';
title('Wang voice');

figure(3) %draw the spectrogram for girl voice 3
t3 = 0:1/fs3:2;
y3 = s3';
y3 = y3(1,:);
spectrogram(y3,window,noverlap,nfft,fs3,'yaxis');
h = colorbar;
%figure('Position', [200 250 800 500]);
h.Label.String = 'Power/Frequency(dB/Hz)';
title('My voice');

figure(4) %draw the spectrogram for boy voice 1
t4 = 0:1/fs4:2;
y4 = s4';
y4 = y4(1,:);
spectrogram(y4,window,noverlap,nfft,fs4,'yaxis');
h = colorbar;
%figure('Position', [200 250 800 500]);
h.Label.String = 'Power/Frequency(dB/Hz)';
title('Wu voice');