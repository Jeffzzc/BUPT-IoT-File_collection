function timeCalculation(n)
ffttime = zeros(1,n);
dfttime = zeros(1,n);

for temp = 1:n
    tic;
    fft(ones(1,temp));
    ffttime(temp) = toc;  %calculate the time consumed for fft
end

for temp = 1:n
    tic;
    DFT(ones(1,temp));
    dfttime(temp) = toc;  %calculate the time consumed for dft
end

figure(1)
loglog((1:n),dfttime); % use loglog to draw
hold on 
loglog((1:n),ffttime); % use loglog to draw
legend('DFT','FFT');
hold off
xlabel('n');
ylabel('Time Used for Calculation');
end