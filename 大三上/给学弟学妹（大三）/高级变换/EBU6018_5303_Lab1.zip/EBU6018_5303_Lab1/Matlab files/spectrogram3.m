%created for part6
[s1,fs1] = audioread('i-dont-understand.wav');
[s2,fs2] = audioread('it-smells-really-good.wav');
[s3,fs3] = audioread('im-so-glad.wav');

%set window parameters
window = hamming(128);
noverlap = 120;
nfft = 2^nextpow2(length(window));

%draw the spectrogram for "i-dont-understand.wav"
figure(1)
t1 = 0:1/fs1:2;
y1 = s1';
y1 = y1(1,:);
spectrogram(y1,window,noverlap,nfft,fs1,'yaxis');
h = colorbar;
%figure('Position', [200 250 800 500]);
h.Label.String = 'Power/Frequency(dB/Hz)';
title('i-dont-understand');

%draw the spectrogram for "it-smells-really-good.wav"
figure(2)
t2 = 0:1/fs2:2;
y2 = s2';
y2 = y2(1,:);
spectrogram(y2,window,noverlap,nfft,fs2,'yaxis');
h = colorbar;
%figure('Position', [200 250 800 500]);
h.Label.String = 'Power/Frequency(dB/Hz)';
title('it-smells-really-good');

%draw the spectrogram for "im-so-glad.wav"
figure(3)
t3 = 0:1/fs3:2;
y3 = s3';
y3 = y3(1,:);
spectrogram(y3,window,noverlap,nfft,fs3,'yaxis');
h = colorbar;
%figure('Position', [200 250 800 500]);
h.Label.String = 'Power/Frequency(dB/Hz)';
title('im-so-glad');