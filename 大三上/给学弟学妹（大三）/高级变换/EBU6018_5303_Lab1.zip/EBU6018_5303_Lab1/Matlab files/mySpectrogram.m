[x1, fs1] = audioread('static.mp3');
[x2, fs2] = audioread('harp.wav');
[x3, fs3] = audioread('heckenbr.wav');
[x4, fs4] = audioread('can-you-keep-a-secret.wav');

%set window parameter
w = 0.54 - 0.46 * cos(2*pi*[0:nfft-1]/(nfft-1));
noverlap = 120;
nfft = 2^nextpow2(length(window));

y1 = x1'; y1 = y1(1,:); %because the sound s is stereo
t1 = 0:1/fs1:2;
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
figure('Position', [200 250 800 250]);
spectrogram(y1,w,noverlap,nfft,fs1,'yaxis'); %draw the spectrogram for "static.mp3"
title( 'static') ;

y2 = x2'; y2 = y2(1,:); %because the sound s is stereo
t2 = 0:1/fs2:2;
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
figure('Position', [200 250 800 250]);
spectrogram(y2,w,noverlap,nfft,fs2,'yaxis'); %draw the spectrogram for "harp.wav"
title( 'harp') ;

y3= x3'; y3 = y3(1,:); %because the sound s is stereo
t3 = 0:1/fs3:2;
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
figure('Position', [200 250 800 250]);
spectrogram(y3,w,noverlap,nfft,fs3,'yaxis'); %draw the spectrogram for "heckenbr.wav"
title( 'heckenbr') ;

y4 = x4'; y4 = y4(1,:); %because the sound s is stereo
t4 = 0:1/fs4:2;
x4 = resample(x4,8000,fs4);
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
figure('Position', [200 250 800 250]);
spectrogram(y4,w,noverlap,nfft,fs4,'yaxis'); %draw the spectrogram for "can-you-keep-a-secret.wav"
title( 'can-you-keep-a-secret') ;