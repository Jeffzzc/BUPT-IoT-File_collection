%created for part7 a and b
[s1,fs1] = audioread('a.m4a');
[s2,fs2] = audioread('i.m4a');
[s3,fs3] = audioread('u.m4a');
[s4,fs4] = audioread('e.m4a');
[s5,fs5] = audioread('o.m4a');

%set parameters
window = hamming(128); %use hamming window
noverlap = 120;
nfft = 2^nextpow2(length(window));

%draw the spectrogram for "a.m4a"
subplot(3,2,1);
t1 = 0:1/fs1:2;
y1 = s1';
y1 = y1(1,:);
spectrogram(y1,window,noverlap,nfft,fs1,'yaxis');
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
title('a');

%draw the spectrogram for "i.m4a"
subplot(3,2,2);
t2 = 0:1/fs2:2;
y2 = s2';
y2 = y2(1,:);
spectrogram(y2,window,noverlap,nfft,fs2,'yaxis');
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
title('i');

%draw the spectrogram for "u.m4a"
subplot(3,2,3);
t3 = 0:1/fs3:2;
y3 = s3';
y3 = y3(1,:);
spectrogram(y3,window,noverlap,nfft,fs3,'yaxis');
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
title('u');

%draw the spectrogram for "e.m4a"
subplot(3,2,4);
t4 = 0:1/fs4:2;
y4 = s4';
y4 = y4(1,:);
spectrogram(y4,window,noverlap,nfft,fs4,'yaxis');
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
title('e');

%draw the spectrogram for "o.m4a"
subplot(3,2,5);
t5 = 0:1/fs5:2;
y5 = s5';
y5 = y5(1,:);
spectrogram(y5,window,noverlap,nfft,fs5,'yaxis');
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
title('o');