function timeCalculation2(n)

for m = 1:n
    x1(m) = m^2;
    x2(m) = m*log10(m); %use these two function for comparison
end

title('Comparison with time consumed for FFT and DFT');
loglog((1:n),x1);
hold on
loglog((1:n),x2);
legend('n^2','nlogn');
hold off
xlabel('n');
ylabel('function value');