%created for part4 a
[s,fs]= audioread('harp.wav' );
soundsc(s,fs);

figure(1)
spectrogram(s);

figure(2)
window = hamming(128); %set window type and length
noverlap = 120;
nfft = 2^nextpow2(length(window));
t = 0:1/fs:2;
y = s';
y = y(1,:); %because the sound s is stereo
spectrogram(y,window,noverlap,nfft,fs,'yaxis');
h = colorbar; %use colorbar
h.Label.String = 'Power/Frequency(dB/Hz)';