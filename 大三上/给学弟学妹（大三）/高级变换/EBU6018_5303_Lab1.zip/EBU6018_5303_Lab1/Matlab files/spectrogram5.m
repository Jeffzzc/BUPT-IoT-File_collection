%created for part7 d
[s1,fs1] = audioread('multimodal.m4a');
s1=resample(s1,8000,fs1); %resample the signals to get clearer spectrograms

%set parameters
window = hamming(128);
noverlap = 120; %noverlap < nfft
nfft = 2^nextpow2(length(window));

t1 = 0:1/fs1:2;
y1 = s1';
y1 = y1(1,:);
spectrogram(y1,window,noverlap,nfft,fs1,'yaxis'); %draw the spectrogram for "multimodal.m4a"
h = colorbar;
h.Label.String = 'Power/Frequency(dB/Hz)';
title('multimodal');