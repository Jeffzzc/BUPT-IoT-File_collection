# gedit: set fileencoding=utf-8 :

import random
import time
from collections import deque

class Node:
    def __init__(self, node_id, target_node_id):
        self.node_id = node_id
        self.target_node_id = target_node_id
        self.queue = deque()  # 用于存储接收到的消息
        self.locked = False  # 用于模拟发送锁

    def read_sensor_data(self):
        # 模拟传感器数据读取
        return random.randint(0, 100)

    def send_data(self, data, nodes):
        # 模拟发送数据
        if self.locked:
            return
        self.locked = True
        print("Node {} sending data: {} to Node {}".format(self.node_id, data, self.target_node_id))
        nodes[self.target_node_id - 1].queue.append((self.node_id, data))
        time.sleep(0.1)  # 模拟发送延迟
        self.locked = False

    def receive_data(self):
        # 模拟接收数据
        if self.queue:
            sender_id, data = self.queue.popleft()
            print("Node {} received data: {} from Node {}".format(self.node_id, data, sender_id))
            return sender_id, data
        return None, None

# 创建三个节点
nodes = [
    Node(1, 2),
    Node(2, 3),
    Node(3, 1)
]

# 模拟通信
def simulate_communication():
    for _ in range(10):  # 模拟10次通信
        for node in nodes:
            data = node.read_sensor_data()
            node.send_data(data, nodes)
        time.sleep(1)  # 模拟通信周期
        for node in nodes:
            node.receive_data()

# 运行仿真
if __name__ == "__main__":
    simulate_communication()



import random
import time
from collections import deque

class Node:
    def __init__(self, node_id, target_node_id):
        self.node_id = node_id
        self.target_node_id = target_node_id
        self.queue = deque()  # 用于存储接收到的消息
        self.locked = False  # 用于模拟发送锁
        self.sent_packets = 0  # 发送的数据包个数
        self.received_packets = 0  # 收到的回应数据包个数
        self.total_delay = 0  # 总时延

    def read_sensor_data(self):
        # 模拟传感器数据读取
        return random.randint(0, 100)

    def send_data(self, data, nodes, log_file):
        # 模拟发送数据
        if self.locked:
            return
        self.locked = True
        self.sent_packets += 1
        print("Node {} sending data: {} to Node {}".format(self.node_id, data, self.target_node_id))
        log_file.write("Node {} sending data: {} to Node {}\n".format(self.node_id, data, self.target_node_id))
        nodes[self.target_node_id - 1].queue.append((self.node_id, data, time.time()))  # 添加发送时间戳
        time.sleep(0.1)  # 模拟发送延迟
        self.locked = False

    def receive_data(self, log_file):
        # 模拟接收数据
        if self.queue:
            sender_id, data, send_time = self.queue.popleft()
            receive_time = time.time()
            delay = receive_time - send_time
            self.received_packets += 1
            self.total_delay += delay
            print("Node {} received data: {} from Node {}, delay: {:.2f}s".format(self.node_id, data, sender_id, delay))
            log_file.write("Node {} received data: {} from Node {}, delay: {:.2f}s\n".format(self.node_id, data, sender_id, delay))
        return None, None

# 创建三个节点
nodes = [
    Node(1, 2),
    Node(2, 3),
    Node(3, 1)
]

# 模拟通信
def simulate_communication():
    with open("simulation_log.txt", "w") as log_file:  # 打开日志文件
        for _ in range(10):  # 模拟10次通信
            for node in nodes:
                data = node.read_sensor_data()
                node.send_data(data, nodes, log_file)
            time.sleep(1)  # 模拟通信周期
            for node in nodes:
                node.receive_data(log_file)

# 运行仿真
if __name__ == "__main__":
    simulate_communication()

  # 计算收包率和时延
    total_sent_packets = sum(node.sent_packets for node in nodes)
    total_received_packets = sum(node.received_packets for node in nodes)
    total_delay = sum(node.total_delay for node in nodes)

    if total_sent_packets > 0:
        packet_delivery_ratio = total_received_packets / total_sent_packets
        average_delay = total_delay / total_received_packets if total_received_packets > 0 else 0
        print("Packet Delivery Ratio: {:.2f}%".format(packet_delivery_ratio * 100))
        print("Average Delay: {:.2f}s".format(average_delay))
    else:
        print("No packets were sent.")

      # 打印每个节点的发送和接收数据包个数
    for node in nodes:
        print("Node {} sent {} packets and received {} packets.".format(node.node_id, node.sent_packets, node.received_packets))
