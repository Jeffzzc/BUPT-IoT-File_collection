module RadioSenseToLeds1C @safe() {
  uses {
    interface Boot;
    interface Receive;
    interface AMSend;
    interface Timer<TMilli> as MilliTimer;
    interface Packet;
    interface Read<uint16_t>;
    interface SplitControl as RadioControl;
  }
}
implementation {

  typedef nx_struct radio_sense_msg_t {
    nx_uint8_t error;
    nx_uint16_t data;
  } radio_sense_msg_t;

  message_t packet;
  bool locked = FALSE;
  uint8_t node_id = 0; // 节点ID
  uint8_t target_node_id = 1; // 目标节点ID

  event void Boot.booted() {
    call RadioControl.start();
    node_id = TOS_NODE_ID; // 获取节点ID
    if (node_id == 1) {
      target_node_id = 2;
    } else if (node_id == 2) {
      target_node_id = 3;
    } else if (node_id == 3) {
      target_node_id = 1;
    }
  }

  event void RadioControl.startDone(error_t err) {
    if (err == SUCCESS) {
      call MilliTimer.startPeriodic(250);
    }
  }
  event void RadioControl.stopDone(error_t err) {}

  event void MilliTimer.fired() {
    call Read.read();
  }

  event void Read.readDone(error_t result, uint16_t data) {
    if (locked) {
      return;
    }
    else {
      radio_sense_msg_t* rsm;

      rsm = (radio_sense_msg_t*)call Packet.getPayload(&packet, sizeof(radio_sense_msg_t));
      if (rsm == NULL) {
        return;
      }
      rsm->error = result;
      rsm->data = data;
      if (call AMSend.send(target_node_id, &packet, sizeof(radio_sense_msg_t)) == SUCCESS) {
        locked = TRUE;
      }
    }
  }

  event message_t* Receive.receive(message_t* bufPtr, 
                                   void* payload, uint8_t len) {
    if (len != sizeof(radio_sense_msg_t)) {
      return bufPtr;
    }
    else {
      radio_sense_msg_t* rsm = (radio_sense_msg_t*)payload;
      uint16_t val = rsm->data;
      // 使用printf输出调试信息
      printf("Node %d received data: %d\n", node_id, val);
      return bufPtr;
    }
  }

  event void AMSend.sendDone(message_t* bufPtr, error_t error) {
    if (&packet == bufPtr) {
      locked = FALSE;
    }
  }

}
