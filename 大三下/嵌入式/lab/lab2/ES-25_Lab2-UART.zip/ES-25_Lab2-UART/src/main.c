#include <platform.h>
#include <gpio.h>
#include <uart.h>
#include "delay.h"
#include "lcd.h"

void main_sample(void){
    // initialisation
    lcd_init();	
	lcd_clear();
    lcd_print("EBU5477 Lab 2");
    lcd_set_cursor(0, 1);

    uart_init(9600);
    uart_enable();
    
    while (1) {
        char c = uart_rx();
        lcd_put_char(c);
    }
}

void main1(void){
}

void main2(void){
}

void main3(void){
}

int main(void) {
    main_sample();
    //main1();
    //main2();
    //main3();
    
    return 0;
}

// ****************************** ARM University Program Copyright � ARM Ltd 2016 ************************************   
// ****************************** Queen Mary University of London Copyright Matthew Tang 2024 ************************
