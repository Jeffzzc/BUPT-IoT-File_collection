#include <platform.h>
#include <gpio.h>
#include <adc.h>
#include <stdio.h>
#include "delay.h"
#include "lcd.h"

#define VREF (3.3)                // ADC????(STM32??3.3V)
#define ADC_RESOLUTION (4096.0)   // 12?ADC???
#define R_KNOWN (2000.0)         // 10kO????

// ??????
float calculate_resistance(int adc_value) {
    if (adc_value <= 0 || adc_value >= ADC_RESOLUTION) {
        return 0.0f; // ???0????
    }

    float Vout = (adc_value * VREF) / ADC_RESOLUTION;
    float Vin = 5.0; // ??????5V

    float Ru = R_KNOWN * Vout / (Vin - Vout);

    return Ru;
}

void main_sample(void) {
    lcd_init();
    lcd_clear();
    lcd_print("Measure Resistor");

    adc_init(PA_1);   // ????PA1?????

    char buffer[16];

    while (1) {
        int adc_value = adc_read(PA_1);  // ????PA1??ADC?

        float resistance = calculate_resistance(adc_value);

        lcd_set_cursor(0, 1);

        if (resistance < 1.0) {
            snprintf(buffer, sizeof(buffer), "Invalid");
        }  
				else {
            snprintf(buffer, sizeof(buffer), "R=%.1f Ohm     ", resistance);
        }

        lcd_print(buffer);

        delay_ms(500);
    }
}

int main(void) {
    main_sample();
    return 0;
}